﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Movies.Client.Services
{
    public interface IIntegrationService
    {
        Task Run();
    }
}
