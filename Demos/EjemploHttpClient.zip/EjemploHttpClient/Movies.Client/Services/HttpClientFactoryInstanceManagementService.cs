﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Movies.Client.Services
{
    public class HttpClientFactoryInstanceManagementService : IIntegrationService
    {  
        public async Task Run()
        {
        }
    }
}
